using System;
using System.Collections.Generic;

namespace LibraryLib
{
    public class LibraryFunctions
    {
        private string libraryName = "Городская библиотека г. Чита";
        private string chiefLibrarian = "Созонов Иван Александрович";

        private List<string> staff = new List<string>()
        {
            "Петров П.С.",
            "Сидорова А.В.",
            "Козлов И.Д.",
            "Иванова М.П."
        };

        // Возвращает ФИО главного библиотекаря.
        public string GetChiefLibrarian()
        {
            return chiefLibrarian;
        }

        // Возвращает название библиотеки.
        public string GetLibraryName()
        {
            return libraryName;
        }

        // Меняет главного библиотекаря, если он есть в списке.
        public void SetChiefLibrarian(string fullname)
        {
            if (staff.Contains(fullname))
            {
                chiefLibrarian = fullname;
                Console.WriteLine("Главный библиотекарь изменён.");
            }
            else
            {
                Console.WriteLine("Такого сотрудника нет в списке.");
            }
        }

        // Создаёт код книги.
        public string GenerateBookCode(string category, int number)
        {
            return category + "_" + number;
        }

        // Возвращает список сотрудников.
        public List<string> GetStaff()
        {
            return staff;
        }

        // Добавляет сотрудника.
        public void AddStaff(string fullname)
        {
            if (fullname != "" && !staff.Contains(fullname))
            {
                staff.Add(fullname);
                Console.WriteLine("Сотрудник добавлен.");
            }
            else
            {
                Console.WriteLine("Нельзя добавить сотрудника.");
            }
        }
    }
}
